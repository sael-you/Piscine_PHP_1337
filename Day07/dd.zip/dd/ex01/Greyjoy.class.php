<?php
    class Greyjoy {
        protected $famillyMotto = "We Do not sow";
    }
?>