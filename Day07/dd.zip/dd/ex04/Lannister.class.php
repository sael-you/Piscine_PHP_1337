<?php
    class Lannister{
        public  function sleepWith($obj)
        {
            echo "Let's do this.";
        }
    }

?>