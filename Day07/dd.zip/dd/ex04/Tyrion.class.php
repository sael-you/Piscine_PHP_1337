<?php
    require_once('Lannister.class.php');
    class Tyrion extends Lannister{
        public function sleepWith($obj)
        {
            if($obj instanceof Cersei || $obj instanceof Jaime)
                echo "Not even if I'm drunk !\n";
            else
                echo "Let's do this.\n";
        }
    }
?>