<?php
    require_once('Lannister.class.php');
    class Jaime extends Lannister{
        public function sleepWith($obj)
        {
            if($obj instanceof Cersei)
                echo "With pleasure, but only in a tower in Winterfell, then.\n";
            else if($obj instanceof Tyrion)
                echo "Not even if I'm drunk !\n";
            else
                echo "Let's do this.\n";
        }
    }
?>