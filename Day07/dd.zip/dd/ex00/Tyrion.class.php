<?php
class Tyrion extends Lannister {


    public $var;


    public function __construct()
    {
        parent::__construct();
        print("My name is Tyrion\n");
    }
    public function getSize()
    {
        $this->$var = 144;
        return "Short";
    }
}
?>
