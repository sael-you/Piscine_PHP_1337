<?php
class NightsWatch
{
    private $array = array();
    public function recruit($obj)
    {
        $this->array[] = $obj;
    }
    public function fight()
    {
        foreach ($this->array as $item) {
            if (method_exists(get_class($item), "fight")) {
                $item->fight();
            }
        }
    }
}
?>