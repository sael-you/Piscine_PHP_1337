<?php
interface IFighter
{
    public function fight();
}
?>